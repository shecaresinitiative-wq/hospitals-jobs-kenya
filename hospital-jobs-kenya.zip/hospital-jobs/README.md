# Hospital Job Applications Portal (Kenya)

Complete recruitment portal for top private hospitals in Mombasa, Kisumu, Nairobi, Eldoret and Bungoma.

## Features

- Multi-step application form
- Region → Top 3 Private Hospitals
- CV + Cover Letter upload
- **Real M-Pesa STK Push** (Till Number) – KSh 1,200
- Hospital-branded PDF confirmation letter + receipt
- Automatic interview booking
- Admin dashboard to view all applicants

## Quick Start

```bash
cd hospital-jobs
npm install
cp .env.example .env
# Edit .env with your M-Pesa credentials
node server.js
```

Open:
- Form: http://localhost:3000
- Admin: http://localhost:3000/admin  (key: admin123)

## Real M-Pesa Setup

1. Go to https://developer.safaricom.co.ke and create an app
2. Get Consumer Key, Consumer Secret, Passkey
3. Use your **Till Number** as `MPESA_SHORTCODE`
4. Set `MPESA_ENV=sandbox` for testing or `production` for live
5. For local testing, expose your server with ngrok and set `MPESA_CALLBACK_URL`

When credentials are missing, the system automatically falls back to simulation mode so you can still test the full flow.

## Admin Panel

- URL: `/admin`
- Default key: `admin123` (change with `ADMIN_KEY` in `.env`)
- View all applications, download CVs, cover letters and the generated PDF letters

## Hospitals (Top 3 Private)

**Mombasa**: Aga Khan Hospital Mombasa, The Mombasa Hospital, Premier Hospital  
**Kisumu**: Aga Khan Hospital Kisumu, Avenue Hospital Kisumu, Kisumu Specialists Hospital  
**Nairobi**: Aga Khan University Hospital, The Nairobi Hospital, MP Shah Hospital  
**Eldoret**: Mediheal Hospital, Eldoret Hospital, Tophill Hospital  
**Bungoma**: LifeCare Hospitals Bungoma, Bungoma West Hospital, New Elgon View Medical Cottage
