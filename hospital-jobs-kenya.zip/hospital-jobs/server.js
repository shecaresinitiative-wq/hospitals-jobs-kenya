try { require('dotenv').config(); } catch (e) { /* optional */ }
const express = require('express');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');
const moment = require('moment');
const axios = require('axios'); // for M-Pesa Daraja

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/letters', express.static(path.join(__dirname, 'generated-letters')));

// Ensure directories exist
['uploads', 'generated-letters'].forEach(dir => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// ========== IN-MEMORY STORE ==========
const applications = [];
let applicationCounter = 1000;
const pendingPayments = {}; // checkoutRequestID → form data

// ========== HOSPITAL DATA ==========
const hospitalsByRegion = {
  "Mombasa": [
    "Aga Khan Hospital Mombasa",
    "The Mombasa Hospital",
    "Premier Hospital (Nyali)"
  ],
  "Kisumu": [
    "Aga Khan Hospital Kisumu",
    "Avenue Hospital Kisumu",
    "Kisumu Specialists Hospital"
  ],
  "Nairobi": [
    "Aga Khan University Hospital Nairobi",
    "The Nairobi Hospital",
    "MP Shah Hospital"
  ],
  "Eldoret": [
    "Mediheal Hospital & Fertility Centre",
    "Eldoret Hospital",
    "Tophill Hospital"
  ],
  "Bungoma": [
    "LifeCare Hospitals Bungoma",
    "Bungoma West Hospital",
    "New Elgon View Medical Cottage"
  ]
};

// Hospital branding for PDF letters
const hospitalBranding = {
  "Aga Khan Hospital Mombasa": {
    name: "Aga Khan Hospital Mombasa",
    color: "#8B0000",
    address: "Vanga Road, Kizingo, Mombasa",
    phone: "+254 722 205 110",
    email: "hr.mombasa@agakhanhospitals.org"
  },
  "The Mombasa Hospital": {
    name: "The Mombasa Hospital",
    color: "#003366",
    address: "Transport Road, Ganjoni, Mombasa",
    phone: "+254 41 231 2191",
    email: "hr@mombasahospital.co.ke"
  },
  "Premier Hospital (Nyali)": {
    name: "Premier Hospital",
    color: "#006666",
    address: "Links Road, Nyali, Mombasa",
    phone: "+254 41 501 1500",
    email: "careers@premierhospital.co.ke"
  },
  "Aga Khan Hospital Kisumu": {
    name: "Aga Khan Hospital Kisumu",
    color: "#8B0000",
    address: "Otieno Oyoo Street, Kisumu",
    phone: "+254 722 203 622",
    email: "hr.kisumu@agakhanhospitals.org"
  },
  "Avenue Hospital Kisumu": {
    name: "Avenue Hospital Kisumu",
    color: "#1a5276",
    address: "Kibuye Market, Kisumu-Kakamega Road",
    phone: "+254 711 060 000",
    email: "hr.kisumu@avenuehealthcare.com"
  },
  "Kisumu Specialists Hospital": {
    name: "Kisumu Specialists Hospital",
    color: "#145a32",
    address: "RIAT Junction, Kisumu-Kakamega Highway",
    phone: "+254 780 154 131",
    email: "recruitment@kisumuspecialists.co.ke"
  },
  "Aga Khan University Hospital Nairobi": {
    name: "Aga Khan University Hospital Nairobi",
    color: "#8B0000",
    address: "3rd Parklands Avenue, Nairobi",
    phone: "+254 20 366 2000",
    email: "hr.nairobi@aku.edu"
  },
  "The Nairobi Hospital": {
    name: "The Nairobi Hospital",
    color: "#1a5276",
    address: "Argwings Kodhek Road, Upper Hill, Nairobi",
    phone: "+254 20 284 5000",
    email: "recruitment@nbihosp.org"
  },
  "MP Shah Hospital": {
    name: "MP Shah Hospital",
    color: "#6c3483",
    address: "Shivaji Road, Parklands, Nairobi",
    phone: "+254 20 4291 100",
    email: "hr@mpshahhosp.org"
  },
  "Mediheal Hospital & Fertility Centre": {
    name: "Mediheal Hospital & Fertility Centre",
    color: "#1a5276",
    address: "Nandi Road, Eldoret",
    phone: "+254 723 578 895",
    email: "careers.eldoret@medihealgroup.com"
  },
  "Eldoret Hospital": {
    name: "Eldoret Hospital",
    color: "#922b21",
    address: "Makasembo Road, Eldoret",
    phone: "+254 722 231 438",
    email: "hr@eldorethospital.com"
  },
  "Tophill Hospital": {
    name: "Tophill Hospital",
    color: "#1b4f72",
    address: "Garden Road, Elgon View, Eldoret",
    phone: "+254 782 900 090",
    email: "recruitment@tophillhospital.co.ke"
  },
  "LifeCare Hospitals Bungoma": {
    name: "LifeCare Hospitals Bungoma",
    color: "#0e6655",
    address: "Mumias Road, next to Christ the King Church, Bungoma",
    phone: "+254 730 950 000",
    email: "hr.bungoma@lchafrica.com"
  },
  "Bungoma West Hospital": {
    name: "Bungoma West Hospital",
    color: "#1a5276",
    address: "Malaba-Eldoret Highway, Kanduyi, Bungoma",
    phone: "+254 724 278 870",
    email: "careers@bungomawesthospital.co.ke"
  },
  "New Elgon View Medical Cottage": {
    name: "New Elgon View Medical Cottage",
    color: "#145a32",
    address: "Mumias - Bungoma Road, Bungoma",
    phone: "+254 55 30698",
    email: "hr@elgonviewmedical.co.ke"
  }
};

const positions = [
  "Registered Nurse", "Enrolled Nurse", "Clinical Officer",
  "Medical Doctor / Medical Officer", "Laboratory Technologist",
  "Pharmacy Technologist", "Radiographer / Imaging Technologist",
  "Physiotherapist", "Health Records Officer", "Hospital Administrator",
  "HR Officer", "Accountant / Finance Officer", "Cleaner / Housekeeping",
  "Security Officer", "Driver / Ambulance Driver", "Other"
];

// ========== MULTER ==========
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => {
    const unique = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /pdf|doc|docx/;
    const ext = allowed.test(path.extname(file.originalname).toLowerCase());
    const mime = allowed.test(file.mimetype) || file.mimetype.includes('document') || file.mimetype.includes('pdf');
    if (ext || mime) return cb(null, true);
    cb(new Error('Only PDF, DOC, DOCX files are allowed'));
  }
});

// ========== M-PESA HELPERS ==========
async function getMpesaAccessToken() {
  const consumerKey = process.env.MPESA_CONSUMER_KEY;
  const consumerSecret = process.env.MPESA_CONSUMER_SECRET;
  if (!consumerKey || !consumerSecret) {
    throw new Error('M-Pesa credentials not configured in .env');
  }

  const auth = Buffer.from(`${consumerKey}:${consumerSecret}`).toString('base64');
  const url = process.env.MPESA_ENV === 'production'
    ? 'https://api.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials'
    : 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';

  const res = await axios.get(url, {
    headers: { Authorization: `Basic ${auth}` }
  });
  return res.data.access_token;
}

function generatePassword() {
  const shortcode = process.env.MPESA_SHORTCODE;
  const passkey = process.env.MPESA_PASSKEY;
  const timestamp = moment().format('YYYYMMDDHHmmss');
  const password = Buffer.from(`${shortcode}${passkey}${timestamp}`).toString('base64');
  return { password, timestamp };
}

// ========== ROUTES ==========

app.get('/api/hospitals/:region', (req, res) => {
  res.json(hospitalsByRegion[req.params.region] || []);
});

app.get('/api/positions', (req, res) => {
  res.json(positions);
});

// --- STK PUSH ---
app.post('/api/stk-push', upload.fields([
  { name: 'cv', maxCount: 1 },
  { name: 'coverLetter', maxCount: 1 }
]), async (req, res) => {
  try {
    const data = req.body;
    const phone = (data.phone || '').replace(/\s+/g, '');

    if (!phone || !/^(?:254|0)?7\d{8}$/.test(phone.replace(/^0/, '254').replace(/^254/, '254'))) {
      return res.status(400).json({ success: false, message: 'Invalid phone number. Use format 07XXXXXXXX' });
    }

    // Normalize phone to 2547XXXXXXXX
    let msisdn = phone;
    if (msisdn.startsWith('0')) msisdn = '254' + msisdn.substring(1);
    if (msisdn.startsWith('7')) msisdn = '254' + msisdn;

    // Save files temporarily linked to this payment
    if (!req.files?.cv || !req.files?.coverLetter) {
      return res.status(400).json({ success: false, message: 'CV and Cover Letter are required' });
    }

    const formSnapshot = {
      ...data,
      phone: msisdn,
      cvPath: req.files.cv[0].filename,
      coverLetterPath: req.files.coverLetter[0].filename,
      createdAt: new Date().toISOString()
    };

    // ===== REAL M-PESA STK PUSH =====
    if (process.env.MPESA_CONSUMER_KEY && process.env.MPESA_CONSUMER_SECRET && process.env.MPESA_SHORTCODE) {
      try {
        const token = await getMpesaAccessToken();
        const { password, timestamp } = generatePassword();
        const shortcode = process.env.MPESA_SHORTCODE;
        const callbackUrl = process.env.MPESA_CALLBACK_URL || `${req.protocol}://${req.get('host')}/api/mpesa-callback`;

        const stkUrl = process.env.MPESA_ENV === 'production'
          ? 'https://api.safaricom.co.ke/mpesa/stkpush/v1/processrequest'
          : 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

        const payload = {
          BusinessShortCode: shortcode,
          Password: password,
          Timestamp: timestamp,
          TransactionType: 'CustomerBuyGoodsOnline', // for Till Number
          Amount: 1200,
          PartyA: msisdn,
          PartyB: shortcode,
          PhoneNumber: msisdn,
          CallBackURL: callbackUrl,
          AccountReference: 'HOSPJOB' + Date.now().toString().slice(-6),
          TransactionDesc: 'Hospital Job Application Fee'
        };

        const stkRes = await axios.post(stkUrl, payload, {
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });

        const checkoutId = stkRes.data.CheckoutRequestID;
        pendingPayments[checkoutId] = formSnapshot;

        return res.json({
          success: true,
          message: 'STK Push sent. Please enter your M-Pesa PIN on your phone.',
          checkoutRequestID: checkoutId,
          merchantRequestID: stkRes.data.MerchantRequestID
        });
      } catch (mpesaErr) {
        console.error('M-Pesa STK Error:', mpesaErr.response?.data || mpesaErr.message);
        return res.status(500).json({
          success: false,
          message: 'Failed to initiate M-Pesa payment. Please try again.',
          detail: mpesaErr.response?.data?.errorMessage || mpesaErr.message
        });
      }
    }

    // ===== FALLBACK SIMULATION (when credentials not set) =====
    console.log('[STK SIMULATED] Real credentials not found – using simulation');
    const fakeCheckout = 'ws_CO_' + Date.now();
    pendingPayments[fakeCheckout] = formSnapshot;

    // Simulate delay then auto-complete (for testing only)
    setTimeout(async () => {
      await completeApplication(fakeCheckout, 'SIM' + Math.random().toString(36).substring(2, 10).toUpperCase());
    }, 4000);

    res.json({
      success: true,
      message: 'STK Push sent (SIMULATED). Waiting for payment...',
      checkoutRequestID: fakeCheckout,
      simulated: true
    });

  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// M-Pesa Callback
app.post('/api/mpesa-callback', async (req, res) => {
  try {
    const body = req.body;
    console.log('M-Pesa Callback received:', JSON.stringify(body, null, 2));

    const result = body.Body?.stkCallback;
    if (!result) return res.json({ ResultCode: 0, ResultDesc: 'Accepted' });

    const checkoutId = result.CheckoutRequestID;
    const resultCode = result.ResultCode;

    if (resultCode === 0) {
      // Success
      const metadata = result.CallbackMetadata?.Item || [];
      const mpesaCode = metadata.find(i => i.Name === 'MpesaReceiptNumber')?.Value || 'UNKNOWN';
      await completeApplication(checkoutId, mpesaCode);
    } else {
      console.log('Payment failed/cancelled for', checkoutId, result.ResultDesc);
      delete pendingPayments[checkoutId];
    }

    res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
  } catch (err) {
    console.error('Callback error:', err);
    res.json({ ResultCode: 0, ResultDesc: 'Accepted' });
  }
});

// Poll payment status (frontend can call this)
app.get('/api/payment-status/:checkoutId', (req, res) => {
  const app = applications.find(a => a.checkoutRequestID === req.params.checkoutId);
  if (app) {
    return res.json({
      status: 'completed',
      refNumber: app.refNumber,
      interviewDate: app.interviewDate,
      interviewTime: app.interviewTime,
      letterUrl: `/letters/${app.refNumber}.pdf`
    });
  }
  if (pendingPayments[req.params.checkoutId]) {
    return res.json({ status: 'pending' });
  }
  res.json({ status: 'not_found' });
});

// Complete application after successful payment
async function completeApplication(checkoutId, mpesaCode) {
  const data = pendingPayments[checkoutId];
  if (!data) return null;

  applicationCounter++;
  const regionCode = (data.region || 'GEN').substring(0, 3).toUpperCase();
  const refNumber = `APP-${regionCode}-2026-${String(applicationCounter).padStart(5, '0')}`;

  // Interview date: 7–12 days ahead, weekday
  let interviewDate = moment().add(9, 'days');
  while (interviewDate.day() === 0 || interviewDate.day() === 6) {
    interviewDate.add(1, 'day');
  }

  const application = {
    id: uuidv4(),
    refNumber,
    checkoutRequestID: checkoutId,
    fullName: data.fullName,
    phone: data.phone,
    email: data.email,
    nationalId: data.nationalId || '',
    region: data.region,
    hospital: data.hospital,
    position: data.position,
    residence: data.residence || '',
    experience: data.experience || '',
    qualification: data.qualification || '',
    notes: data.notes || '',
    cvPath: data.cvPath,
    coverLetterPath: data.coverLetterPath,
    amount: 1200,
    mpesaCode,
    paymentStatus: 'PAID',
    paidAt: new Date().toISOString(),
    interviewDate: interviewDate.format('dddd, D MMMM YYYY'),
    interviewTime: '9:00 AM – 12:00 PM',
    createdAt: new Date().toISOString()
  };

  applications.push(application);
  delete pendingPayments[checkoutId];

  // Generate hospital-branded PDF
  const pdfPath = await generateHospitalLetter(application);

  // Send email
  await sendConfirmationEmail(application, pdfPath);

  console.log(`Application completed: ${refNumber} for ${application.fullName}`);
  return application;
}

// ========== IMPROVED HOSPITAL-BRANDED PDF ==========
function generateHospitalLetter(appData) {
  return new Promise((resolve, reject) => {
    const brand = hospitalBranding[appData.hospital] || {
      name: appData.hospital,
      color: '#1a5276',
      address: 'Kenya',
      phone: '',
      email: 'hr@hospital.co.ke'
    };

    const doc = new PDFDocument({ margin: 50, size: 'A4' });
    const filename = `${appData.refNumber}.pdf`;
    const filepath = path.join(__dirname, 'generated-letters', filename);
    const stream = fs.createWriteStream(filepath);
    doc.pipe(stream);

    const primary = brand.color;

    // ===== HEADER BAND =====
    doc.rect(0, 0, 595, 90).fill(primary);
    doc.fillColor('#FFFFFF').fontSize(16).font('Helvetica-Bold')
       .text(brand.name.toUpperCase(), 50, 28, { align: 'left' });
    doc.fontSize(9).font('Helvetica')
       .text('Human Resources Department • Recruitment Office', 50, 50);
    doc.fontSize(8)
       .text(`${brand.address}  |  ${brand.phone}`, 50, 65);

    // ===== DOCUMENT TITLE =====
    doc.fillColor('#000000').moveDown(3);
    doc.fontSize(13).font('Helvetica-Bold')
       .text('APPLICATION CONFIRMATION & INTERVIEW INVITATION', 50, 110, { align: 'center' });
    doc.moveDown(0.3);
    doc.fontSize(9).font('Helvetica').fillColor('#555')
       .text('This document also serves as your official payment receipt', { align: 'center' });

    // Reference box
    doc.moveDown(0.8);
    doc.rect(50, doc.y, 495, 28).fill('#f4f6f7');
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold')
       .text(`Reference Number: ${appData.refNumber}`, 60, doc.y - 20);
    doc.fillColor('#000').font('Helvetica').fontSize(9)
       .text(`Date Issued: ${moment().format('D MMMM YYYY')}`, 350, doc.y - 20);

    let y = doc.y + 25;

    // ===== CANDIDATE DETAILS =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('CANDIDATE DETAILS', 50, y);
    y += 18;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).lineWidth(1).stroke();
    y += 12;

    doc.fillColor('#000').font('Helvetica').fontSize(10);
    const leftCol = [
      ['Full Name', appData.fullName],
      ['Phone Number', appData.phone],
      ['Email', appData.email],
      ['National ID / Passport', appData.nationalId || 'Not provided']
    ];
    const rightCol = [
      ['Region', appData.region],
      ['Hospital', appData.hospital],
      ['Position Applied', appData.position],
      ['Residence', appData.residence || 'Not provided']
    ];

    leftCol.forEach((row, i) => {
      doc.font('Helvetica-Bold').text(row[0] + ':', 50, y + (i * 16));
      doc.font('Helvetica').text(row[1], 160, y + (i * 16));
    });
    rightCol.forEach((row, i) => {
      doc.font('Helvetica-Bold').text(row[0] + ':', 320, y + (i * 16));
      doc.font('Helvetica').text(row[1], 420, y + (i * 16), { width: 125 });
    });

    y += 80;

    // ===== PAYMENT RECEIPT =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('PAYMENT RECEIPT', 50, y);
    y += 18;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).stroke();
    y += 12;

    doc.fillColor('#000').fontSize(10);
    doc.font('Helvetica-Bold').text('Amount Paid:', 50, y);
    doc.font('Helvetica').text('KSh 1,200.00', 160, y);
    doc.font('Helvetica-Bold').text('Payment Method:', 320, y);
    doc.font('Helvetica').text('M-Pesa (STK Push)', 420, y);
    y += 16;
    doc.font('Helvetica-Bold').text('M-Pesa Code:', 50, y);
    doc.font('Helvetica').text(appData.mpesaCode, 160, y);
    doc.font('Helvetica-Bold').text('Payment Date:', 320, y);
    doc.font('Helvetica').text(moment(appData.paidAt).format('D MMM YYYY, h:mm A'), 420, y);
    y += 16;
    doc.font('Helvetica-Bold').text('Status:', 50, y);
    doc.fillColor('#006600').font('Helvetica-Bold').text('SUCCESSFULLY RECEIVED', 160, y);
    y += 20;
    doc.fillColor('#555').fontSize(8).font('Helvetica')
       .text('This letter is your official receipt for the non-refundable application processing fee of Kenya Shillings One Thousand Two Hundred Only.', 50, y, { width: 495 });
    y += 30;

    // ===== INTERVIEW DETAILS =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('INTERVIEW DETAILS', 50, y);
    y += 18;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).stroke();
    y += 12;

    doc.fillColor('#000').fontSize(10).font('Helvetica')
       .text('Your application has been successfully received and processed by our recruitment team.', 50, y);
    y += 18;

    // Highlight box
    doc.rect(50, y, 495, 55).fill('#fef9e7');
    doc.fillColor('#000').font('Helvetica-Bold').fontSize(10)
       .text(`Interview Date:   ${appData.interviewDate}`, 65, y + 12);
    doc.text(`Interview Time:   ${appData.interviewTime}`, 65, y + 28);
    doc.font('Helvetica').text(`Venue:   Human Resources Department, ${brand.name}`, 65, y + 42);
    y += 70;

    doc.fontSize(9).fillColor('#333')
       .text('Mode: In-person  •  Please arrive 30 minutes early. You will receive an SMS/email reminder 24 hours before the interview.', 50, y);
    y += 25;

    // ===== WHAT TO BRING =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('WHAT TO BRING TO THE INTERVIEW', 50, y);
    y += 16;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).stroke();
    y += 12;

    doc.fillColor('#000').font('Helvetica').fontSize(9);
    const items = [
      '1. This confirmation letter (printed)',
      '2. Original National ID or Passport + one photocopy',
      '3. Updated Curriculum Vitae (CV)',
      '4. Cover Letter',
      '5. Original academic certificates & transcripts + photocopies',
      '6. Professional registration certificates (Nursing Council, KMPDC, etc.) if applicable',
      '7. Two recent passport-size photographs',
      '8. Any other supporting documents relevant to the position'
    ];
    items.forEach(item => {
      doc.text(item, 55, y);
      y += 13;
    });
    y += 10;

    // ===== IMPORTANT NOTES =====
    doc.fillColor(primary).fontSize(11).font('Helvetica-Bold').text('IMPORTANT NOTES', 50, y);
    y += 16;
    doc.moveTo(50, y).lineTo(545, y).strokeColor(primary).stroke();
    y += 12;

    doc.fillColor('#000').fontSize(8).font('Helvetica');
    const notes = [
      '• Please dress formally / smart casual.',
      '• This application fee of KSh 1,200 is non-refundable.',
      '• Failure to attend the scheduled interview without prior written notice may result in your application being closed.',
      '• Keep this letter safely — it is your official proof of application and payment.',
      '• For any enquiries, contact the hospital HR office using the details at the top of this letter.'
    ];
    notes.forEach(n => {
      doc.text(n, 50, y, { width: 495 });
      y += 12;
    });
    y += 15;

    // ===== CLOSING =====
    doc.fontSize(10).text('We look forward to meeting you.', 50, y);
    y += 25;

    doc.font('Helvetica-Bold').text('Authorised by:', 50, y);
    y += 30;
    doc.moveTo(50, y).lineTo(200, y).stroke();
    y += 8;
    doc.font('Helvetica').fontSize(9)
       .text('Recruitment Administrator', 50, y)
       .text(`Human Resources Department`, 50, y + 12)
       .text(brand.name, 50, y + 24);

    // Footer
    doc.fontSize(7).fillColor('#888')
       .text('This is a computer-generated document issued upon successful payment. It is valid without a physical signature.', 50, 780, { align: 'center', width: 495 });

    doc.end();
    stream.on('finish', () => resolve(filepath));
    stream.on('error', reject);
  });
}

// ========== EMAIL ==========
async function sendConfirmationEmail(appData, pdfPath) {
  if (!process.env.SMTP_HOST) {
    console.log(`[EMAIL SIMULATED] To: ${appData.email} | Ref: ${appData.refNumber}`);
    return;
  }
  try {
    const transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: process.env.SMTP_PORT || 587,
      secure: false,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
    });
    await transporter.sendMail({
      from: `"${appData.hospital} Recruitment" <${process.env.SMTP_USER}>`,
      to: appData.email,
      subject: `Application Received – ${appData.refNumber} | ${appData.hospital}`,
      text: `Dear ${appData.fullName},\n\nYour application to ${appData.hospital} has been received.\n\nReference: ${appData.refNumber}\nInterview: ${appData.interviewDate} at ${appData.interviewTime}\n\nPlease find attached your official confirmation letter and payment receipt.\n\nBest regards,\nHuman Resources\n${appData.hospital}`,
      attachments: [{ filename: `${appData.refNumber}.pdf`, path: pdfPath }]
    });
  } catch (err) {
    console.error('Email error:', err.message);
  }
}

// ========== ADMIN PAGE DATA ==========
app.get('/api/admin/applications', (req, res) => {
  // Simple password protection
  const key = req.headers['x-admin-key'] || req.query.key;
  if (key !== (process.env.ADMIN_KEY || 'admin123')) {
    return res.status(401).json({ success: false, message: 'Unauthorized' });
  }
  res.json({
    success: true,
    total: applications.length,
    applications: applications.map(a => ({
      refNumber: a.refNumber,
      fullName: a.fullName,
      phone: a.phone,
      email: a.email,
      region: a.region,
      hospital: a.hospital,
      position: a.position,
      mpesaCode: a.mpesaCode,
      paidAt: a.paidAt,
      interviewDate: a.interviewDate,
      interviewTime: a.interviewTime,
      cvPath: a.cvPath,
      coverLetterPath: a.coverLetterPath,
      letterUrl: `/letters/${a.refNumber}.pdf`
    })).reverse()
  });
});

// Serve admin page
app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

// Root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start
app.listen(PORT, () => {
  console.log(`\n🚀 Hospital Jobs Portal running at http://localhost:${PORT}`);
  console.log(`   Admin panel: http://localhost:${PORT}/admin`);
  console.log(`   Default admin key: admin123 (change via ADMIN_KEY in .env)\n`);
  if (!process.env.MPESA_CONSUMER_KEY) {
    console.log('⚠️  M-Pesa credentials not set – STK Push will run in SIMULATION mode.\n');
  }
});