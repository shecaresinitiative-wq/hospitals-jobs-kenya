# Hospital Jobs Kenya

Existing Hospital Jobs Kenya application migrated from Safaricom Daraja STK Push to PayHero. The existing frontend, application workflow, admin dashboard, document generation, email and JSON persistence are retained.

## Payment integration

- Provider: PayHero M-Pesa STK Push
- Existing application fee: **KSh 1,200 (unchanged)**
- PayHero account ID: `13884`
- Payment channel ID: `1828680`
- STK endpoint: `POST https://backend.payhero.co.ke/api/v2/payments`
- Callback endpoint: `POST /api/payhero/callback`
- A queued STK request is not treated as payment. A successful callback is correlated to the stored checkout and external reference, checked for exact amount, phone and receipt, and independently verified through PayHero transaction status before an application is marked PAID.

## Run locally

1. Install Node.js 18+
2. Run `npm install`
3. Copy `.env.example` to `.env` and set the PayHero API password and public HTTPS callback URL.
4. Run `npm start`
5. Open `http://localhost:3000` (admin: `/admin`).

## Production environment variables

| Variable | Value / purpose |
|---|---|
| `PAYHERO_API_USERNAME` | Existing PayHero API username |
| `PAYHERO_API_PASSWORD` | Existing PayHero API password (secret) |
| `PAYHERO_ACCOUNT_ID` | `13884` |
| `PAYHERO_CHANNEL_ID` | `1828680` |
| `PAYHERO_BASE_URL` | `https://backend.payhero.co.ke` |
| `PAYHERO_PROVIDER` | `m-pesa` |
| `PAYHERO_CALLBACK_URL` | Optional override; Render automatically uses `RENDER_EXTERNAL_URL/api/payhero/callback` when omitted |
| `ADMIN_KEY` | Existing admin key / secret |
| `DATA_DIR` | `/var/data` on Render persistent disk |
| `UPLOADS_DIR` | `/var/data/uploads` |
| `LETTERS_DIR` | `/var/data/generated-letters` |

The server generates the HTTP Basic Authorization header from the username and password. No credentials are stored in frontend files or this ZIP. `PAYHERO_BASIC_AUTH_TOKEN` is supported as an alternative if the account requires the supplied token instead.

## Render deployment

The included `render.yaml` provisions a persistent disk at `/var/data`. Configure the environment variables above in Render. The app automatically derives its callback from Render’s `RENDER_EXTERNAL_URL` when `PAYHERO_CALLBACK_URL` is not set. You can override it if you use a custom domain. Remove obsolete `MPESA_*` Daraja variables from the service environment.

## Payment safety

- Unique external reference per checkout, mapped to PayHero's CheckoutRequestID.
- Kenyan phone numbers normalized to international `254` format.
- Callback external reference and checkout ID must match the pending order.
- Payment amount must equal the existing KSh 1,200 fee; phone and receipt are checked.
- PayHero transaction status is independently queried before fulfillment.
- Duplicate checkout IDs and M-Pesa receipts are rejected.
- Status polling performs fallback status reconciliation. If PayHero's status response omits the amount, the application deliberately remains pending rather than assuming the correct amount.
- Failed, cancelled and pending states are retained; unresolved transactions are not prematurely deleted.
- No development payment simulation is enabled.

## Testing status

Static syntax checks can be performed locally, but a real end-to-end payment requires deployment with the live PayHero credentials, a reachable callback URL and a customer-initiated M-Pesa transaction. This package does not claim a live transaction has been tested.
