# Migration change log

- Replaced Safaricom Daraja STK initiation with PayHero `POST /api/v2/payments`.
- Added PayHero Basic Authentication from server-side environment variables.
- Configured PayHero account `13884` and channel `1828680`.
- Added `/api/payhero/callback`, external-reference/checkout matching, exact-amount/phone/receipt checks and independent transaction-status verification.
- Added pending/failed/cancelled handling, status polling reconciliation and duplicate protection.
- Preserved the original **KSh 1,200** application fee and all unrelated application features.
- Retired the legacy Daraja callback route with HTTP 410.
- No live PayHero transaction has been performed in this environment.
