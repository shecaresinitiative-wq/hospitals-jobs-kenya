# Hospital Job Applications Portal (Kenya)

Recruitment portal for top private hospitals in Mombasa, Kisumu, Nairobi, Eldoret and Bungoma.

## Features

- Multi-step application form
- Region → Top 3 Private Hospitals
- CV + Cover Letter upload
- Real M-Pesa STK Push (Buy Goods Till) – **KSh 1200** interview booking fee
- Strong server-side payment verification (amount, phone, receipt, idempotency)
- Hospital-branded PDF confirmation letter + receipt (download protected until paid)
- Automatic interview date generation (unchanged rules)
- Persistent storage (survives restarts)
- Admin dashboard (applications, payment status, receipts, documents)

## Quick Start

```bash
cd hospital-jobs
npm install
cp .env.example .env
# Edit .env with your M-Pesa credentials and ADMIN_KEY
node server.js
```

Open:

- Form: http://localhost:3000
- Admin: http://localhost:3000/admin  (key from `ADMIN_KEY`, default initial: Brayo123)

## Environment variables (required for production)

| Variable | Description |
|----------|-------------|
| `ADMIN_KEY` | Admin dashboard password (set to a strong unique value) |
| `MPESA_CONSUMER_KEY` | Daraja consumer key |
| `MPESA_CONSUMER_SECRET` | Daraja consumer secret |
| `MPESA_SHORTCODE` | Till number (e.g. 1828680) |
| `MPESA_PASSKEY` | Daraja passkey |
| `MPESA_ENV` | `production` or `sandbox` |
| `MPESA_CALLBACK_URL` | Public HTTPS URL to `/api/mpesa-callback` |
| `DATA_DIR` / `UPLOADS_DIR` / `LETTERS_DIR` | Optional; use Render disk paths |

Optional: SMTP_* for confirmation emails.

## M-Pesa (Daraja) – production Till

1. Create an app at https://developer.safaricom.co.ke
2. Use production credentials and set `MPESA_ENV=production`
3. `MPESA_SHORTCODE` = your Buy Goods **Till Number** (1828680)
4. Transaction type used: `CustomerBuyGoodsOnline`
5. `MPESA_CALLBACK_URL` must be public HTTPS (your Render URL + `/api/mpesa-callback`)

A payment is marked **PAID** only when the callback reports success, CheckoutRequestID matches a pending request, amount is exactly the configured fee, phone matches (when present), a receipt number is present, and the receipt has not been used before.

If credentials are missing, the app falls back to simulation for local testing only. Do not use simulation in production.

## Admin

- URL: `/admin`
- Key: value of `ADMIN_KEY` (initial request: Brayo123 – change before public launch)
- Rate limited after repeated failed logins
- Letters and uploads are not publicly listable; letter download requires a per-application token

## Persistence (Render)

Applications, pending payments and counter are stored as JSON under `DATA_DIR` (default `./data`).  
On Render, attach a **persistent disk** and set:

```
DATA_DIR=/var/data
UPLOADS_DIR=/var/data/uploads
LETTERS_DIR=/var/data/generated-letters
```

Without a disk, data is lost on restart/redeploy.

## Hospitals (Top 3 Private)

**Mombasa**: Aga Khan Hospital Mombasa, The Mombasa Hospital, Premier Hospital  
**Kisumu**: Aga Khan Hospital Kisumu, Avenue Hospital Kisumu, Kisumu Specialists Hospital  
**Nairobi**: Aga Khan University Hospital, The Nairobi Hospital, MP Shah Hospital  
**Eldoret**: Mediheal Hospital, Eldoret Hospital, Tophill Hospital  
**Bungoma**: LifeCare Hospitals Bungoma, Bungoma West Hospital, New Elgon View Medical Cottage
